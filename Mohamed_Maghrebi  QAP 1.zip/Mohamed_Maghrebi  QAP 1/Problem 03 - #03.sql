DELETE FROM address
WHERE address = 'tunisia_street 555'
and district = 'east'
and city_id = 5
and postal_code = '55555'