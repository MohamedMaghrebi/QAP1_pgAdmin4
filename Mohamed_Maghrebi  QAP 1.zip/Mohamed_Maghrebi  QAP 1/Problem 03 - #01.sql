INSERT INTO address (address, district, city_id, postal_code, phone)
VALUES  ('tunisia_street 555','east',5,'55555','98587382');
 
INSERT INTO customer (first_name, last_name, address_id, email, store_id )
VALUES
    ('Alex', 'Mac', 1, 'alex@hotmail.com', 1),  
    ('Roy', 'Mac', 1, 'roy@hotmail.com', 2),
    ('Miro', 'Mac', 1, 'miro@hotmail.com', 3);