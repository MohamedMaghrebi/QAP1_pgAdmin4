SELECT film_id, title, release_year, rental_rate
FROM film
ORDER BY rental_rate DESC;